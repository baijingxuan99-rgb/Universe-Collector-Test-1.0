﻿宇宙收藏家 V10 · Windows PC 试玩

请解压全部文件，再用 Chrome 或 Edge 打开 START.html。
白天最多探索两次。确认傍晚手作后，今晚可以普通营业。
