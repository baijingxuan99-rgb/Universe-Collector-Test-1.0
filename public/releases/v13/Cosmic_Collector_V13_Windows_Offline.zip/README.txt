﻿宇宙收藏家 V13 · Windows PC 试玩

解压后用 Chrome 或 Edge 打开 START.html。
在店里选择「合奏节目单 · 琴房之夜」，查看访客收益与聘用说明。
