﻿宇宙收藏家 V15 · Windows PC 试玩

解压后用 Chrome 或 Edge 打开 START.html。
需要快进时打开 TEST.html。两个入口分开存档。
