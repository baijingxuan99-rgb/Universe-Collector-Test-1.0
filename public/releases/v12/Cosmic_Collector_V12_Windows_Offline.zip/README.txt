﻿宇宙收藏家 V12 · Windows PC 试玩

解压后用 Chrome 或 Edge 打开 START.html。
探索时左上显示本委托线索，打开右下笔记进行推演。
