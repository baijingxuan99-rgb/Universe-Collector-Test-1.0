﻿宇宙收藏家 V14 · Windows PC 试玩

解压后用 Chrome 或 Edge 打开 START.html。
完成巴黎琴房合奏后，进入莫扎特画室。小店备货页可扩建后厅。
