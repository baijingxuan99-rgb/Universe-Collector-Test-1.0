﻿宇宙收藏家 V11 · Windows PC 试玩

请解压后，用 Chrome 或 Edge 打开 START.html。
琴房第三日委托后可参加终场合奏，倒数 3 秒。Space 落舞步，Enter 应弦。
